<?php
// Note: This file is included from the library/People/People.Control.PeopleFoot.php class.

echo '</div>
<div class="Foot'.$this->CssClass.'"><a href="http://lussumo.com">Lussumo Vanilla, Swell, and People</a> Copyright &copy; 2001-2006</div>';
?>