<?php
// Note: This file is included from the library/Vanilla/Vanilla.Control.Account.php class.
if (ForceIncomingString('PostBackAction', '') == '') {
   echo '</div>';
}
?>