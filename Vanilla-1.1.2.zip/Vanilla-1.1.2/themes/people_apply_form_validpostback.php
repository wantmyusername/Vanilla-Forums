<?php
// Note: This file is included from the library/People/People.Control.ApplyForm.php class.

echo '<div class="FormComplete">
   <h2>'.$this->Context->GetDefinition('ThankYouForInterest').'</h2>
   <ul>
      <li>'.$this->Context->GetDefinition('ApplicationWillBeReviewed').'</li>
   </ul>
</div>';
?>