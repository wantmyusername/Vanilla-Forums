<?php
// Note: This file is included from the library/Framework/Framework.Control.PageEnd.php class.

echo '</body>
</html>';
?>